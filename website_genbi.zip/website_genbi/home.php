<!DOCTYPE html>
<head>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> WEB DESAIGN </title>
	<link rel="stylesheet" type="text/css" href="s.css"/>
	<link href="css/font-awesome.min.css" rel="stylesheet" />
	<link rel="shortcut icon" type="image/png" href="img/favicon.png"/>
</head>
<body>
	<header>
		<div id="header-inner">
			<!-- <a href="index.html" id="logo"><a/> -->
			<nav>
				<a href="#" id="menu-icon"><a/>
				<ul>
					<li><a href="index.html" class="current">HOME</a></li>
					<li><a href="#">CONTACT</a></li>
					<!-- <li><a href="#">ABOUT</a></li>
					<li><a href="#">CHANEL</a></li> -->
					<li><a href="login.php">LOGIN</a></li>
			
					</ul>
				</nav>
			</div>
	</header>
<!---End header-->
	<section class="banner">
		<div class="banner-inner">
			<img src="logo/logo.png">
		<div>
	</section>
<!---End Banner-->
	<section class="one-fourth" id="html">
		<td><i class="fa fa-html5"></i></td>
		<h3><a href="users.php" style="text-decoration: none;">BERITA GENBI</a></h3>
	</section>
	<section class="one-fourth" id="css">
		<td><i class="fa fa-css3"></i></td>
		<h3>PROFIL</h3>
	</section>
	<section class="one-fourth" id="seo">
		<td><i class="fa fa-search"></i></td>
		<h3>SEJARAH</h3>
	</section>
	<section class="one-fourth" id="social">
		<td><i class="fa fa-users"></i></td>
		<h3>SOSIAL</h3>
	</section>
<!---End Four Column Section-->
	
	<section class="inner-wrapper">
		<article id="tablet">
			<img src="img/logo2.png" width=15%>
		</article>
		<aside id="tablet2">
			<h2> KATA MUTIARA SATU </h2>
			<p> Dalam hidup, terkadang kita membutuhkan kata kata mutiara atau kata kata bijak kehidupan sebagai 
				pengingat untuk bisa menjadi manusia yang lebih baik. Meskipun begitu, kita harus bisa
				mengamalkannya dengan perbuatan juga.

				Dalam hidup, terkadang kita membutuhkan kata kata mutiara atau kata 
				kata bijak kehidupan sebagai pengingat untuk bisa menjadi manusia yang lebih baik. Meskipun begitu, 
				kita harus bisa mengamalkannya dengan perbuatan juga.

				Dalam hidup, terkadang kita membutuhkan kata kata mutiara atau kata kata bijak 
				kehidupan sebagai pengingat untuk bisa menjadi manusia yang lebih baik. Meskipun begitu, 
				kita harus bisa mengamalkannya dengan perbuatan juga.
			</p>
		</aside>
		</section>
		<section class="inner-wrapper-2">
			<article id="mobile">
				<h2> KATA MUTIARA DUA </h2>
				<p>	Dalam hidup, terkadang kita membutuhkan kata kata mutiara 
					atau kata kata bijak kehidupan sebagai pengingat untuk bisa menjadi manusia 
					yang lebih baik. Meskipun begitu, kita harus bisa mengamalkannya dengan perbuatan juga.Dalam hidup, t
					erkadang kita membutuhkan kata kata mutiara atau kata kata bijak kehidupan sebagai pengingat untuk 
					bisa menjadi manusia yang lebih baik. Meskipun begitu, kita harus bisa mengamalkannya dengan perbuatan juga.Dalam 
					hidup, terkadang kita membutuhkan kata kata mutiara atau kata kata bijak kehidupan sebagai pengingat untuk
					bisa menjadi manusia yang lebih baik. Meskipun begitu, kita harus bisa mengamalkannya dengan perbuatan juga.Dalam hidup, 
					terkadang kita membutuhkan kata kata mutiara atau kata kata bijak kehidupan sebagai pengingat untuk bisa menjadi
					manusia yang lebih baik. Meskipun begitu, kita harus bisa mengamalkannya dengan perbuatan juga.</p>

			</article>
			<aside class="hand-mobile">
				<img src="img/logo3.png">
			</aside>
		</section>
		<section class="inner-wrapper">
			<article>
				<img src="img/logo4.png" width="100%">
			</article>
			<aside id="desktop">
				<p>Dalam hidup, terkadang kita membutuhkan kata kata mutiara Dalam hidup, terkadang kita membutuhkan
				kata kata mutiara Dalam hidup, terkadang kita membutuhkan kata kata mutiara Dalam hidup, 
				terkadang kita membutuhkan kata kata mutiara Dalam hidup, terkadang kita membutuhkan kata kata mutiara Dalam hidup, t
				erkadang kita membutuhkan kata kata mutiara Dalam hidup, terkadang kita membutuhkan kata kata mutiara 
				</p>
			</aside>
			</section>
<!---End min two column sections-->
	<section class="inner-wrapper-3">
		<section class="one-third" id="google">
			<h3> GOOGLE </h3>
			<p>Berikut ini adalah beberapa kata kata bijak kehidupan dari tokoh tokoh terkenal yang bisa kamu pahami 
			maknanya dan dijadikan inspirasi. Kamu bisa menempelnya di meja belajar atau cermin agar bisa lebih 
			meresapinya. Lalu, kamu bisa menerapkannya di kehidupan sehari hari.</p>
		</section>
		<section class="one-third" id="marketing">
		<h3> MARKETING </h3>
		<p>Berikut ini adalah beberapa kata kata bijak kehidupan dari tokoh tokoh terkenal yang bisa kamu pahami 
		maknanya dan dijadikan inspirasi. Kamu bisa menempelnya di meja belajar atau cermin agar bisa lebih meresapinya.
		Lalu, kamu bisa menerapkannya di kehidupan sehari hari.</p>
		</section>
		<section class="one-third" id="customers">
		<h3> HAPPY CUSTOMERS </h3>
		<p>Berikut ini adalah beberapa kata kata bijak kehidupan dari tokoh tokoh terkenal yang bisa kamu pahami
		dari tokoh tokoh terkenal yang bisa kamu pahamidari tokoh tokoh terkenal yang bisa kamu pahamidari tokoh 
		tokoh terkenal yang bisa kamu pahami dari tokoh tokoh terkenal yang bisa kamu 
		</p>
		</section>
	</section>
<!--- End Three Costum Section-->
	<section id="smiley">
		<h2> : ) </h2>
	</section>
<!---end smiley face-->
	<footer>
		<ul class="social">
			<li><a href="https://www,facebook.com/w3newbie" target="-blank"><i class="fa fa-facebook">f</i></a></li>
			<li><a href="https://plus.google.com/+DrewRyan_w3/posts"><i class="fa fa-google-plus">g+</i></a></li>
			<li><a href="https://twitter.com/DrewOnCue"><i class="fa fa-twitter">t</i></a></li>
			<li><a href="https://youtube.com/user/DrewOnCue"><i class="fa fa-youtube">y</i></a></li>
			<li><a href="https://www.instagram.com/Drew_Ryan_/"><i class>i</i></a></li>
		</ul>
	</footer>
<!--- End footer section -->
	<footer class="second">
		<p>&copyrocket design</p>
	</footer>
<!---End second footer--?



</body>
</html>