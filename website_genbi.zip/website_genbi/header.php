<?php 
	require ('functions.php');
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>GenBI BERITA</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
		<header>
			<img src="logo/logo.PNG">
			<ul>
				<li><a href="home.php">HOME</a></li>
				<li><a href="#">ABOUT</a></li>
				<li><a href="#">CONTACT</a></li>
			</ul>

		</header>

		<div class="clear"></div>
		

</body>
</html>